import { CircularProgressbar, buildStyles } from 'react-circular-progressbar'
import { useBudget } from '../hooks/useBudget'

import AmountDisplay  from './AmountDisplay'
import 'react-circular-progressbar/dist/styles.css'

const BudgetTracker = () => {

  const { state, dispatch, totalSpent, remaining } = useBudget()

  const percentageSpent = +((totalSpent / state.budget) * 100).toFixed(2)

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="flex justify-center">
          <CircularProgressbar
            value={percentageSpent}
            text={`${percentageSpent} % Gastado`}
            styles={buildStyles({
              pathColor: percentageSpent === 100 ? '#dc2626' : '#3b82f6',
              textColor: percentageSpent === 100 ? '#dc2626' : '#3b82f6',
              textSize: '8px',
              trailColor: '#f5f5f5'
            })}
          />
        </div>

        <div className="flex flex-col justify-center items-center gap-8">
          <button
            type="button"
            className="bg-pink-600 w-full p-2 text-white uppercase font-bold rounded-lg"
            onClick={() => dispatch({type: 'reset-app'})}
          >
            Resetear App
          </button>

          <AmountDisplay 
            label="Presupuesto"
            amount={state.budget}
          />

          <AmountDisplay 
            label="Disponible"
            amount={remaining}
          />

          <AmountDisplay 
            label="Gastado"
            amount={totalSpent}
          />

        </div>
      </div>
    </>
  )
}

export default BudgetTracker
