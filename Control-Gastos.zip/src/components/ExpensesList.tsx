import { useMemo } from "react"
import { useBudget } from "../hooks/useBudget"
import ExpensesDetail from "./ExpensesDetail"

const ExpensesList = () => {

  const { state } = useBudget()

  const filterSpends = state.currentFilter ? state.expenses.filter(expense => expense.category === state.currentFilter) : state.expenses
  const isEmpty = useMemo(() => filterSpends.length === 0, [state.expenses])


  return (
    <div className="bg-white shadow-lg rounded-lg p-10 mt-10">
      { isEmpty ? (
        <p className="text-gray-600 text-2xl my-5">No hay gastos</p>
      ) : (
        <>
          <p className="text-gray-600 text-2xl font-bold my-5">
            Listado de Gastos.
          </p>

          {filterSpends.map(expense => (
            <ExpensesDetail key={expense.id} expense={expense} />
          ))}
        </>
      )}
    </div>
  )
}

export default ExpensesList
