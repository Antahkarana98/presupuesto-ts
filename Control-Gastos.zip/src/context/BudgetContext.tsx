import { useReducer, createContext, Dispatch, ReactNode, useMemo } from 'react';
import { BudgetActions, budgetReducer, BudgetState, intialState } from '../reducers/budget-reducer';

type BudgetContextProps = {
  state: BudgetState
  dispatch: Dispatch<BudgetActions>
  totalSpent: number
  remaining: number
}

type BudgetProviderProps = {
  children: ReactNode
}

export const BudgetContext = createContext<BudgetContextProps>(null!)

export const BudgetProvider = ({children} : BudgetProviderProps) => {

  const [state, dispatch] = useReducer(budgetReducer, intialState)

  const totalSpent = useMemo(() => { 
    return state.expenses.reduce((total, expense) => total + expense.amount, 0)
  }
  , [state.expenses])

  const remaining = state.budget - totalSpent

  return (
    <BudgetContext.Provider
      value={{
        state,
        dispatch,
        totalSpent,
        remaining
      }}
    >
      {children}
    </BudgetContext.Provider>
  )
}