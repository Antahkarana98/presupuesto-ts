import { v4 as uuidv4 } from 'uuid'
import { Category, DraftExpense, Expense } from "../types"

export type BudgetActions =
  { type: 'add-budget', payload: { budget: number } } |
  { type: 'show-modal' } |
  { type: 'close-modal' } |
  { type: 'add-expense', payload: {expense: DraftExpense} } |
  { type: 'delete-expense', payload: {id: Expense['id']} } |
  { type: 'get-expense-by-id', payload: {id: Expense['id']} } |
  { type: 'update-expense', payload: {expense: Expense} } |
  { type: 'reset-app'} |
  { type: 'add-filter', payload: {id: Category['id']} }


export type BudgetState = {
  budget: number
  showModal: boolean
  expenses: Expense[]
  editingExpenseId: Expense['id']
  currentFilter: Category['id']
}

const initialBudget = () : number => {
  const localStoragebudget = localStorage.getItem('budget')
  return localStoragebudget ? +localStoragebudget : 0
}

const localStorageExpenses = () : Expense[] => {
  const localStorageExpenses = localStorage.getItem('expenses')
  return localStorageExpenses ? JSON.parse(localStorageExpenses) : []
}

export const intialState: BudgetState = {
  budget: initialBudget(),
  showModal: false,
  expenses: localStorageExpenses(),
  editingExpenseId: '',
  currentFilter: ''
}

const createExpense = (draftExpense: DraftExpense) => {
  return {
    ...draftExpense,
    id: uuidv4(),
  }
}

export const budgetReducer = (
    state: BudgetState, 
    action: BudgetActions
  ) => {

    if (action.type === 'add-budget') {
      return {
        ...state,
        budget: action.payload.budget
      }
    }

    if(action.type === 'show-modal') {
      return {
        ...state,
        showModal: true
      }
    }

    if(action.type === 'close-modal') {
      return {
        ...state,
        showModal: false,
        editingExpenseId: ''
      }
    }

    if(action.type === 'add-expense') {

      const expense = createExpense(action.payload.expense)

      return {
        ...state,
        expenses: [...state.expenses, expense],
        showModal: false
      }
    }

    if(action.type === 'get-expense-by-id') {
      return {
        ...state,
        editingExpenseId: action.payload.id,
        showModal: true
      }
    }

    if(action.type === 'update-expense') {
      return {
        ...state,
        expenses: state.expenses.map(expense => ( expense.id === action.payload.expense.id ? action.payload.expense : expense )),
        editingExpenseId: '',
        showModal: false
      }
    }

    if(action.type === 'delete-expense') {
      return {
        ...state,
        expenses: state.expenses.filter(expense => expense.id !== action.payload.id)
      }
    }

    if(action.type === 'reset-app') {
      return {
        ...state,
        budget: 0,
        expenses: [],
      }
    }

    if(action.type === 'add-filter') {
      return {
        ...state,
        currentFilter: action.payload.id
      }
    }

    return state
  }